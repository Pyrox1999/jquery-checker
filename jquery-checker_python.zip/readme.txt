This app Tests, if a Website uses jquery. And when yes, it gives you the Version. And if the Version is older, it says you, what for hack-attacks are possible on this site like:
"XSS vulnerability"
"Selector injection"
"Prototype pollution"

Music by SubspaceAudio